<?php
// modules/interactions/add_ajax.php
session_start();
require_once '../../config/database.php';
require_once '../../includes/auth.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

checkAuth();

try {
    $customer_id = (int)$_POST['customer_id'];
    $type = $_POST['type'];
    $subject = $_POST['subject'];
    $description = $_POST['description'] ?? '';
    $interaction_date = $_POST['interaction_date'];
    $status = $_POST['status'] ?? 'completed';
    $follow_up_date = !empty($_POST['follow_up_date']) ? $_POST['follow_up_date'] : null;
    
    // Validasyon
    if (!$customer_id || !$type || !$subject || !$interaction_date) {
        throw new Exception('Gerekli alanlar eksik');
    }
    
    // Müşteri var mı kontrol et
    $stmt = $db->prepare("SELECT id FROM customers WHERE id = ?");
    $stmt->execute([$customer_id]);
    if (!$stmt->fetch()) {
        throw new Exception('Müşteri bulunamadı');
    }
    
    // İletişim kaydını ekle
    $stmt = $db->prepare("
        INSERT INTO customer_interactions (
            customer_id, user_id, type, subject, description, 
            interaction_date, status, follow_up_date, created_at
        ) VALUES (
            ?, ?, ?, ?, ?, ?, ?, ?, NOW()
        )
    ");
    
    $stmt->execute([
        $customer_id,
        $_SESSION['user_id'],
        $type,
        $subject,
        $description,
        $interaction_date,
        $status,
        $follow_up_date
    ]);
    
    echo json_encode(['success' => true, 'message' => 'İletişim kaydı başarıyla eklendi']);
    
} catch (Exception $e) {
    http_response_code(400);
    echo json_encode(['error' => $e->getMessage()]);
}
?>